package com.oriondev.moneywallet.model;

/**
 * Created by andrea on 20/12/18.
 */
public enum DataFormat {
    CSV,
    XLS,
    PDF
}